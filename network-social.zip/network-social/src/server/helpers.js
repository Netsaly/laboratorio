const moment = require('moment');
const helpers = {};


helpers.tiempoPublicacion = timestamp =>{
    return   moment(timestamp).startOf('hour').fromNow();
} 

module.exports = helpers;
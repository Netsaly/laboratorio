$('#post-coment').hide()

$('#btn-toggle-comment').click(e =>{
    e.preventDefault();
    $('#post-coment').slideToggle();
});

$('#btn-like').click(function(e){
    e.preventDefault();
    let imgId=$(this).data('id');
    
   $.post('/images/'+ imgId+'/like')
    .done(data =>{
        $('.likes-count').text(data.likes); 
    })
})

$('#btn-delete').click(function(e){
    e.preventDefault();
    let $this=$(this);
    const resp= confirm('¿Estas seguro de querer eliminar la imagen?');
    if(resp){
        let imgId = $this.data('id');
        $.ajax({
            url:'/images/'+imgId,
            type: 'DELETE'
        })
        .done(function(result){
            $this.removeClass('btn-danger').addClass('btn-success');
            $this.find('i').removeClass('fa-times').addClass('fa-check')
            $this.removeClass('Borrar')
            $this.append('<span> Eliminado </span>')    
        })
    }

})
 
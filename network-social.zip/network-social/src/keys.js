module.exports = {
    database:{
        URI:'mongodb://localhost/imgshare',

    }
};
const Stats = require('./stats');
const Images = require('./images');
const Comments =require('./comments');


module.exports = async viewModel => {
    
    const resultado = await Promise.all([
    Stats(),
    Images.popular(),
    Comments.noticias(),
    

]);
    viewModel.sidebar ={
        stats: resultado[0],
        imagenes: resultado[1],
        comentarios: resultado[2]
        
    }

    return viewModel;
};

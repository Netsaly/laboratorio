const helpers = {};

helpers.randomNumber = () =>{
    const posible = 'asdfghjklqwertyuiopzxcvbnm123654789';
    let randomNumber=0;


    for (let i=0; i < 8; i++){
        randomNumber += posible.charAt(Math.floor(Math.random() * posible.length))
    }
    return randomNumber;
};

module.exports=helpers;
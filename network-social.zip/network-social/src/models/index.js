module.exports={
    Image: require('./image'),
    Comment: require('./comments')
};

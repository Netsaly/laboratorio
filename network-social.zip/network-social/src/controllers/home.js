const ctrl={};
const {Image}=require('../models')
const sidebar= require('../helpers/sidebar')

ctrl.index = async (req,res)=>{
    const images = await Image.find().sort({timestap:-1});
    let viewModels = {images:[]};
    viewModels.images = images;
    viewModels =  await sidebar(viewModels);
    console.log(viewModels)
    res.render('index',{viewModels});
}




module.exports=ctrl;
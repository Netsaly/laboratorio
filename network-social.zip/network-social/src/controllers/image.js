const path = require('path')
const {randomNumber}=require('../helpers/libs');
const fs=require('fs-extra');
const {Image, Comment}=require('../models');
const md5= require('md5');
const ctrl={};
const sidebar=require('../helpers/sidebar')


ctrl.index =  async (req,res)=>{
    const img= await Image.findOne({filename: {$regex:req.params.image_id}});
    let viewModel = {img:{}, comments:{}}
     if(img){
        img.views = img.views + 1;
        viewModel.img = img;
        await img.save();
        const comments= await Comment.find()
        viewModel.comments=comments; 
        viewModel=await sidebar(viewModel);
       res.render('image',viewModel);
     } else{
         res.redirect('/')
     }
}

ctrl.create=async (req,res)=>  {

    const imgUrl=randomNumber();
    const saveImage = async ()=>{
        const images= await Image.find({filename:imgUrl});
            if(images.length>0){
                saveImage();
            } else{

            
    
        const ext=path.extname(req.file.originalname).toLowerCase();
        const imageTempPath = req.file.path;
        const targetPath= path.resolve(`src/public/upload/${imgUrl}${ext}`)
        
        if(ext==='.png'||ext==='.jpg' || ext==='.jpeg' || ext==='.png' || ext==='.png' ){
            await fs.rename(imageTempPath,targetPath)
            const newImg = new Image({
                    title: req.body.title,
                    filename:imgUrl+ext, 
                    description:req.body.description,
                    
            });
                console.log(newImg)
                const imagenSave = await newImg.save();
                res.redirect('/images/'+imgUrl);
                
        }else {
             await fs.unlink(imageTempPath);
             res.status(500).json({error:'extension de formato no permitido'})
        }
        
    

    }}
        saveImage();
    
}

ctrl.like= async (req,res)=>{
    const image = await Image.findOne({filename:{$regex: req.params.image_id}})
    if( image){
        image.likes = image.likes + 1;
         await image.save();
         res.json({likes: image.likes})
    }
}

ctrl.comment= async  (req,res)=> {
    const image= await Image.findOne({filename:{$regex: req.params.image_id}});
        if(image){
            const newComment = new Comment(req.body);
            newComment.gravatar = md5(newComment.email)
            newComment.image_id = image._id;
            await newComment.save(); 

            res.redirect('/images/'+image.uniqueId+'#'+newComment._id);  
                  
        }  else {
            res.redirect('/');
        }
    
    

    
}

ctrl.remove= async(req,res)=>{
    const img= await Image.findOne({filename:{$regex: req.params.image_id}});
    if(img){
            await fs.unlink(path.resolve('./src/public/upload/'+ img.filename))
            await Comment.deleteOne({image_id: img._id});
            await img.remove();
            res.json(true);
            
    }
}
module.exports=ctrl;